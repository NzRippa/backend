package com.tweetapp.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TweetAppUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(TweetAppUserApplication.class, args);
	}

}
