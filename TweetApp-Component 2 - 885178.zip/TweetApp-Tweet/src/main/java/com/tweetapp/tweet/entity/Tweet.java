package com.tweetapp.tweet.entity;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Tweet {

	@Id
	private String id;
	private String email;
	@NotEmpty(message = "Please type some message !")
	@Size(max = 144)
	private String description;
	private int likes;
	private List<Tweet> replies;
	private Date date;

	public Tweet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Tweet(String id, String email, String description, int likes, List<Tweet> replies, Date date) {
		super();
		this.id = id;
		this.email = email;
		this.description = description;
		this.likes = likes;
		this.replies = replies;
		this.date = date;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getLikes() {
		return likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}

	public List<Tweet> getReplies() {
		return replies;
	}

	public void setReplies(List<Tweet> replies) {
		this.replies = replies;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
